package com.adventnet.nms.poll.graphs;

public interface JVMGraphController
{
    public void fetchData(String pDataName, long startTime, long endTime);
}




