package com.adventnet.nms.poll.graphs;

// import java classes
import java.util.Vector;

public interface CollectedGraphController
{
    public void fetchData(Vector instances, long startTime, long endTime);
}

