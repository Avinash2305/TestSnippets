echo Please change the path to point to your JDK 1.3 or later directory

JAVA_HOME=/usr/java/jdk1.3

if [ ! -f $JAVA_HOME/bin/java ]
then
echo
echo  	Please edit this shell file to change the path to
echo         point to JDK 1.3 or later 
echo
exit 1
fi
echo	Compiling Source files. please wait......

$JAVA_HOME/bin/idlj -fall -td ./idl_src/. ./idls/Device.idl

NMS_HOME=../..

CLASSPATH=$NMS_HOME/classes:.:./webnms/classes

export CLASSPATH

$JAVA_HOME/bin/javac -d ./webnms/classes ./idl_src/com/adventnet/nms/example/southboundcorba/device/*.java

cp -fR ./webnms/classes ./agent 

if [ -f ./agent/classes/corbasouthboundexample.jar ]
then rm ./agent/classes/corbasouthboundexample.jar
fi

$JAVA_HOME/bin/javac -d ./webnms/classes ./webnms/src/*.java
$JAVA_HOME/bin/javac -d ./agent/classes ./agent/src/*.java

cd webnms/classes

$JAVA_HOME/bin/jar -cvf corbasouthboundexample.jar com/adventnet/nms/example/southboundcorba/*.class
$JAVA_HOME/bin/jar -uvf corbasouthboundexample.jar com/adventnet/nms/example/southboundcorba/device/*.class

echo done
echo
