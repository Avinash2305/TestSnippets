#!/bin/sh
#$Id: CORBAClientDemo_Scalar.sh,v 1.2 2007/09/07 15:38:23 venkatramanan Exp $

NMS_HOME=../..

JAVA_HOME=$NMS_HOME/jre

$JAVA_HOME/bin/java -cp $JAVA_HOME/lib/rt.jar:$NMS_HOME/examples/classes:$NMS_HOME/classes/NmsServerClasses.jar:$NMS_HOME/classes:$NMS_HOME/classes/AdventNetWebNmsAgent.jar:$NMS_HOME/classes/xmojo.jar:$NMS_HOME/classes/AdventNetJmxAgent.jar:$NMS_HOME/classes/AdventNetARUtils.jar:$NMS_HOME/classes/SNMPDebugger.jar:./classes com.adventnet.nms.example.jmxagent.CORBAClientDemo_Scalar -HOST localhost -PORT 1050
