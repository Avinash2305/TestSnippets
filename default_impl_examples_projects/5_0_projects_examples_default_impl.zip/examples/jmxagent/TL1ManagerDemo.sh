#!/bin/sh
#$Id: TL1ManagerDemo.sh,v 1.2 2007/09/07 15:38:23 venkatramanan Exp $

NMS_HOME=../..
NMS_CLASSES=$NMS_HOME/classes

JAVA_HOME=$NMS_HOME/jre

CLASS_PATH=$JAVA_HOME/lib/rt.jar:$NMS_HOME/examples/classes:$NMS_HOME/classes/NmsServerClasses.jar:$NMS_HOME/classes:$NMS_CLASSES/AdventNetWebNmsAgent.jar:$NMS_CLASSES/AdventNetTL1.jar:$NMS_CLASSES/ManagementServer.jar:$NMS_CLASSES/ManagementClient.jar:$NMS_CLASSES/xalan.jar:$NMS_CLASSES/crimson.jar:$NMS_CLASSES/jaxp.jar:./classes:$NMS_CLASSES/AdventNetSnmp.jar:$NMS_CLASSES/SNMPDebugger.jar:$NMS_CLASSES/AdventNetCLI.jar

$JAVA_HOME/bin/java -cp $CLASS_PATH -DMS_ROOT_DIR=$NMS_HOME com.adventnet.nms.example.jmxagent.TL1ManagerDemo -HOST localhost -PORT 9099 

