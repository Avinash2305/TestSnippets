#$Id: deploy_nms.sh,v 1.4 2008/04/01 12:46:48 venkatramanan Exp $ 
# This script creates the webnms.ear with NMS_HOME as reference.
# This involves creation of webnms.war, webnms.sar and creating the .ear file with other necessary files from Web NMS home.
#!/bin/sh

JDK_HOME=/home/test/java/j2sdk1.4.2_07
export JDK_HOME

if [ ! -f $JDK_HOME/bin/javac -o -z "$JDK_HOME" ]
then
  echo "javac not found. Please configure JDK_HOME environment variable in $0 file."
  exit 1
fi

fe_flag=0
if [ $# -eq 0 ]
then NMS_HOME=../..

elif [ $# -eq 1 -a $1 = FE ]
then
NMS_HOME=../..
fe_flag=1

elif [ $# -eq 1 -a $1 != FE ]
then
NMS_HOME=$1
fe_flag=0

elif [ $# -eq 2 -a $2 = FE ]
then
NMS_HOME=$1
fe_flag=1

elif [ $# -eq 2 -a $1 = FE ]
then
NMS_HOME=$2
fe_flag=1

elif [ $# -gt 2 ]
then
echo "Number of arguments can only be 0, 1 or 2. Usage: deploy_nms.bat [NMS_HOME] [FE]"
exit 1
fi

echo ""
echo "********************************************************************************************************************"
echo "checking for build.xml ..."
if [ -f ./build.xml -a $fe_flag -eq 0 ]
then
        echo "Using build.xml from the current directory"
        echo ""
        PATH=$PATH:.
        export PATH
        BUILDXML=./build.xml
        break
elif [ -f $NMS_HOME/examples/jboss/build.xml -a $fe_flag -eq 0 ]
then
        echo "build.xml is not present in the current directory. Using  $NMS_HOME/examples/jboss/build.xml"
        echo ""
        PATH=$PATH:$NMS_HOME/examples/jboss
        export PATH
        BUILDXML=$NMS_HOME/examples/jboss/build.xml
break
elif [ ! -f ./build.xml -a ! -f $NMS_HOME/examples/jboss/build.xml ]
then
echo "It seems build.xml is not present in the current directory and in NMS_HOME. Hence unable to proceed with the build"
echo "Ensure to have build.xml either in the current directory or in NMS_HOME/examples/jboss and restart the build"
echo "********************************************************************************************************************"
exit 1
fi

echo "********************************************************************************************************************"
if [ -f ./fe_build.xml -a $fe_flag -eq 1 ]
then
	echo "FE Build. checking for fe_build.xml ..."
        echo "Using fe_build.xml from the current directory"
        PATH=$PATH:.
        export PATH
        BUILDXML=./fe_build.xml
        break
elif [ -f $NMS_HOME/examples/jboss/build.xml -a $fe_flag -eq 1 ]
then
        echo "fe_build.xml is not present in the current directory. Using $NMS_HOME/examples/jboss/fe_build.xml"
        echo ""
        PATH=$PATH:$NMS_HOME/examples/jboss
        export PATH
        BUILDXML=$NMS_HOME/examples/jboss/fe_build.xml
break
elif [ $fe_flag -eq 1 -a ! -f ./fe_build.xml -a ! -f $NMS_HOME/examples/jboss/fe_build.xml ]
then
echo "It seems fe_build.xml is not present in the current directory and in NMS_HOME. Hence unable to proceed with FE deployment"
echo "Ensure to have fe_build.xml either in the current directory or in NMS_HOME/examples/jboss and restart the FE deployment"
echo "********************************************************************************************************************"
exit 1
fi

flag=1
if [ ! -f  $NMS_HOME/AdventNetLicense.ali -a $fe_flag -eq 0 ];
then
flag=0
missingfiles="AdventNetLicense.ali"
fi

if [ ! -f $NMS_HOME/COPYRIGHT -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", COPYRIGHT"
fi

if [ ! -f $NMS_HOME/LICENSE_AGREEMENT ];
then
flag=0
missingfiles=$missingfiles", LICENSE_AGREEMENT"
fi

if [ ! -d $NMS_HOME/NetMonitor ];
then
flag=0
missingfiles=$missingfiles", NetMonitor"
fi

if [ ! -d $NMS_HOME/Themes -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", Themes"
fi

if [ ! -d $NMS_HOME/apache ];
then
flag=0
missingfiles=$missingfiles", apache"
fi

if [ ! -d $NMS_HOME/bsh-scripts -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", bsh-scripts"
fi

if [ ! -d $NMS_HOME/ccs -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", ccs"
fi

if [ ! -d $NMS_HOME/classes ];
then
flag=0
missingfiles=$missingfiles", classes"
fi

if [ ! -d $NMS_HOME/conf ];
then
flag=0
missingfiles=$missingfiles", conf"
fi

if [ ! -d $NMS_HOME/configtasks -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", configtasks"
fi

if [ ! -d $NMS_HOME/data ];
then
flag=0
missingfiles=$missingfiles", data"
fi

if [ ! -f $NMS_HOME/favicon.ico ];
then
flag=0
missingfiles=$missingfiles", favicon.ico"
fi

if [ ! -d $NMS_HOME/genTrap ];
then
flag=0
missingfiles=$missingfiles", genTrap"
fi

if [ ! -d $NMS_HOME/html ];
then
flag=0
missingfiles=$missingfiles", html"
fi

if [ ! -d $NMS_HOME/icons ];
then
flag=0
missingfiles=$missingfiles", icons"
fi

if [ ! -d $NMS_HOME/idls -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", idls"
fi

if [ ! -d $NMS_HOME/images ];
then
flag=0
missingfiles=$missingfiles", images"
fi

if [ ! -d $NMS_HOME/lib ];
then
flag=0
missingfiles=$missingfiles", lib"
fi

if [ ! -d $NMS_HOME/listmenus ];
then
flag=0
missingfiles=$missingfiles", listmenus"
fi

if [ ! -d $NMS_HOME/mapdata ];
then
flag=0
missingfiles=$missingfiles", mapdata"
fi

if [ ! -d $NMS_HOME/mibs ];
then
flag=0
missingfiles=$missingfiles", mibs"
fi

if [ ! -d $NMS_HOME/mysql ];
then
flag=0
missingfiles=$missingfiles", mysql"
fi

if [ ! -d $NMS_HOME/projects -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", projects"
fi

if [ ! -d $NMS_HOME/provisioningresults -a $fe_flag -eq 0 ];
then
missingfiles=$missingfiles", provisioningresults"
.xml"
fi

if [ ! -d $NMS_HOME/provisioningtemplates -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", provisioningtemplates"
uild.xml"
fi

if [ ! -d $NMS_HOME/reports -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", reports"
fi

if [ ! -d $NMS_HOME/state -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", state"
fi

if [ ! -d $NMS_HOME/stylesheets -a $fe_flag -eq 0 ];
then
flag=0
missingfiles=$missingfiles", stylesheets"
fi

if [ ! -d $NMS_HOME/users ];
then
flag=0
missingfiles=$missingfiles", users"
fi

if [ ! -d $NMS_HOME/WEB-INF ];
then
flag=0
missingfiles=$missingfiles", WEB-INF"
fi

if [ ! -d $NMS_HOME/jsp ];
then
flag=0
missingfiles=$missingfiles", jsp"
fi

if [ ! -d $NMS_HOME/webclient ];
then
flag=0
missingfiles=$missingfiles", webclient"
fi

if [ $flag -eq 0 ];
then
echo ""
echo "The following files or folders are not present in NMS_HOME"
echo "Either include them under NMS_HOME or remove the corresponding copy entries in NMS_HOME/examples/jboss/build.xml"
echo $missingfiles
echo "*****************************************************************************************************************"
exit 1
fi

if [ $flag -eq 1 ];
then
export NMS_HOME
ant -f $BUILDXML
fi

exit 1
