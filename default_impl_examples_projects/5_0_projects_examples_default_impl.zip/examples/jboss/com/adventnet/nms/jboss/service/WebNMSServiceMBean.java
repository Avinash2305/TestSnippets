//$Id: WebNMSServiceMBean.java,v 1.2 2008/03/21 14:09:07 jeyaprakash Exp $

package com.adventnet.nms.jboss.service;

import org.jboss.system.ServiceMBean;

/**
 * Mbean interface to the Web NMS Service.
 *
 * @see ServiceMBean
 */
public interface WebNMSServiceMBean
    extends ServiceMBean
{
    /**
     * Sets the arguments used to start Web NMS BE Server 
     * from JBoss Application Server.
     *
     * @param args a <code>String</code> value
     */
    public void setArgs(String args);
    
    /**
     * Returns the arguments used to start Web NMS BE Server 
     * from JBoss Application Server.
     *
     * @return a <code>String</code> value
     */
    public String getArgs();

    public void setBindName(String name);

    public String getBindName();
}
