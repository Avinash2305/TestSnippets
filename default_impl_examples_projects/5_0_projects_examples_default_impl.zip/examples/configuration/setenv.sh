#!/bin/sh
NMS_HOME=../..
PATH=$NMS_HOME/jre/bin:$PATH
CLASSPATH=$NMS_HOME/examples/classes:$NMS_HOME/classes/ManagementServer.jar:$NMS_HOME/classes/AdventNetSnmp.jar:$NMS_HOME/classes/crimson.jar:$NMS_HOME/classes/AdventNetFramework.jar:$NMS_HOME/classes/xalan.jar:
export CLASSPATH
export PATH	
