#!/bin/sh
# Takes a backup of the conf files that this example overrides.

NMS_HOME=../..
cp -f $NMS_HOME/conf/discovery.filters      ./backup/conf
cp -f $NMS_HOME/conf/map.filters            ./backup/conf
cp -f $NMS_HOME/conf/relationalclasses.conf ./backup/conf

