#!/bin/sh
# Installs the Group Interface Example.

sh preinstall_backup.sh
NMS_HOME=../..

cp ./classes/test/IPService.class         $NMS_HOME/classes/test
cp ./classes/test/ServiceFilter.class     $NMS_HOME/classes/test
cp ./classes/test/ServiceMapFilter.class  $NMS_HOME/classes/test

cp ./conf/discovery.filters               $NMS_HOME/conf/discovery.filters
cp ./conf/map.filters                     $NMS_HOME/conf/map.filters
cp ./conf/relationalclasses.conf          $NMS_HOME/conf/relationalclasses.conf
echo
echo Group Interface Example successfully installed..
echo Reinitialize and restart the server.
echo


