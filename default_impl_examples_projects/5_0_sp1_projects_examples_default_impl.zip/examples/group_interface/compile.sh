#!/bin/sh
# Compiles the Services Example
# Please change the JAVA_HOME Path to jdk 1.2 or greater
# This batch file compiles the files for the group interface example.

NMS_HOME=../..
JAVA_HOME=$NMS_HOME/jre/bin
PATH=$JAVA_HOME:$PATH
CLASSPATH=$NMS_HOME/classes:$NMS_HOME/classes/AdventNetSnmp.jar:$NMS_HOME/examples/classes:$NMS_HOME/classes/NmsServerClasses.jar
export CLASSPATH
export PATH

echo Compiling sources, please wait.....

javac -d ./classes ./src/*.java

echo done.
