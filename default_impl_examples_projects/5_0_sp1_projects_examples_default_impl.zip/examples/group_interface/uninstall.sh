#!/bin/sh
# Un-installs the Services Example

NMS_HOME=../..
cp -f ./backup/conf/discovery.filters       $NMS_HOME/conf/
cp -f ./backup/conf/map.filters             $NMS_HOME/conf/
cp -f ./backup/conf/relationalclasses.conf  $NMS_HOME/conf/

rm -f ./backup/conf/discovery.filters
rm -f ./backup/conf/map.filters      
rm -f ./backup/conf/relationalclasses.conf
                                          
rm -f $NMS_HOME/classes/test/IPService.class
rm -f $NMS_HOME/classes/test/ServiceFilter.class
rm -f $NMS_HOME/classes/test/ServiceMapFilter.class
echo
echo Group Interface Example successfully un-installed..
echo
