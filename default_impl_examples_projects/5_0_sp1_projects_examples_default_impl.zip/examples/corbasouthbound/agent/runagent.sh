echo Edit the Initial value of HOST and PORT.

JAVA_HOME=../../../jre

if [ ! -f $JAVA_HOME/bin/java ]
then
echo
echo  	Please edit this batch file to change the path to
echo         point to JDK 1.2 or later 
echo
exit 1
fi
CLASSPATH=.:./classes:../../classes
export CLASSPATH
$JAVA_HOME/bin/java com.adventnet.nms.example.southboundcorba.DeviceServer -ORBInitialHost localhost -ORBInitialPort 1050
