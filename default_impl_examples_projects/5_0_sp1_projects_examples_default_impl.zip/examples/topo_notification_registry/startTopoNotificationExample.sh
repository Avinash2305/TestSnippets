#!/bin/sh
# $Id: startTopoNotificationExample.sh,v 1.2 2007/09/07 15:38:25 venkatramanan Exp $
# This shell file is used for running the TopoNotification example.
 
if [ $# -ne 1 ] 
then
 echo USAGE: sh startTopoNotificationExample.sh HostName
 exit
fi

cd ../..
NMS_HOME=.

PATH=$NMS_HOME/jre/bin:$PATH

export CLASSPATH

CLASSPATH=$CLASSPATH:$NMS_HOME/classes:$NMS_HOME/examples/classes:$NMS_HOME/classes/NmsServerClasses.jar:.:$NMS_HOME/classes/xalan.jar:$NMS_HOME/classes/crimson.jar:$NMS_HOME/classes/AdventNetSnmp.jar:$NMS_HOME/classes/jaxp.jar:$NMS_HOME/classes/SNMPDebugger.jar

java -cp $CLASSPATH NetDiscoveryStatusHandler $1

cd examples/topo_notification_registry
