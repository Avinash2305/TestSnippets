#!/bin/sh
# $Id: compileTopoNotificationExample.sh,v 1.2 2007/09/07 15:38:25 venkatramanan Exp $ 
# This batch file compiles the source files for the TopoNotificationRegistry Example and places
# it under the Nms classes directory.

#Please change the JAVA_HOME variable to point to jdk1.2.2 or later

NMS_HOME=../..
JAVA_HOME=$NMS_HOME/jre/bin

CLASSPATH=$NMS_HOME/classes:$NMS_HOME/examples/classes:$NMS_HOME/classes/NmsServerClasses.jar:.
export CLASSPATH

PATH=$JAVA_HOME:$PATH

echo Compiling sources, please wait.....

javac -d $NMS_HOME/classes *.java
rmic  -d $NMS_HOME/classes test.NetDiscoveryStatusListener

echo done.
