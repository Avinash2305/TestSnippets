// $Id: WebNMSFEServiceMBean.java,v 1.1 2008/03/25 13:36:33 aravinds Exp $
package com.adventnet.nms.jboss.service;

import org.jboss.system.ServiceMBean;

/**
 * Mbean interface to the Web NMS FE Service.
 *
 * @see ServiceMBean
 */

public interface WebNMSFEServiceMBean extends ServiceMBean
{
    /**
     * Sets the bind name of NameLookup interface in JNDI.
     *
     * @param name a <code>String</code> bind name.
     */
    public void setBindName(String name);
    
    /**
     * Returns the bind name of NameLookup interface in JNDI.
     *
     * @return a <code>String</code> bind name.
     */
    public String getBindName();

    /**
     * Sets the arguments used to start Web NMS FE Server 
     * from JBoss Application Server.
     *
     * @param args a <code>String</code> value
     */
    public void setArgs(String args);
    
    /**
     * Returns the arguments used to start Web NMS FE Server 
     * from JBoss Application Server.
     *
     * @return a <code>String</code> value
     */
    public String getArgs();
}

