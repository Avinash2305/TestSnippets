// $Id: WebNMSService.java,v 1.5 2008/04/18 14:01:52 venkatramanan Exp $

package com.adventnet.nms.jboss.service;

import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import com.adventnet.nms.admin.ShutDownAPIImpl;
import com.adventnet.launcher.nms.StartNmsJdbc;
import com.adventnet.nms.fe.common.naming.NameLookup;
import com.adventnet.nms.fe.common.naming.NameLookupImpl;
import org.jboss.system.ServiceMBeanSupport;

/**
 * Initializes the Web NMS BE Server as service in JBoss Application
 * Server, with the specified arguments. Based on the given
 * parameters, this service MBean starts, Web NMS Back-End Server and
 * Apache Webserver with Tomcat web-container.
 *
 * @see ServiceMBeanSupport
 * @see WebNMSServiceMBean 
 */
//@Service (objectName="jboss:service=WebNMSService")
//@Management(com.adventnet.nms.jboss.WebNMSServiceMBean.class)
public class WebNMSService extends ServiceMBeanSupport implements WebNMSServiceMBean
{
    private String m_args;

    private String nms_home;

    private String m_name;
    /**
     * Constructs a new <code>WebNMSService</code> instance.
     */
    public WebNMSService ()
    {
        System.out.println(" [JBoss-WebNMS] : WebNMSService constructor called !! ");//No I18N
    }

    
    /**
     * Sets the arguments used to start Web NMS BE Server 
     * from JBoss Application Server.
     *
     * @param args a <code>String</code> value
     */
    public void setArgs(String args)
    {
        System.out.println(" [JBoss-WebNMS] : ARGS == > "+args );//No I18N
        m_args = args;
    }
    
    /**
     * Returns the arguments used to start Web NMS BE Server 
     * from JBoss Application Server.
     *
     * @return a <code>String</code> value
     */
    public String getArgs()
    {
        return m_args;
    }

    /**
     * Starts the Web NMS BE Server and Apache Web Server, also,
     * NameLookup interface is bound in JNDI.
     *
     * @exception Exception if an error occurs
     */

    public void setBindName(String name)
    {
	    m_name=name;
    }

    public String getBindName()
    {
	    return m_name;
    }

    public void startService() throws Exception
    {
        System.out.println(" [JBoss-WebNMS] : Starting Web NMS BEServer in JBoss..!!" );//No I18N
	try
	{
		String[] args = formArray(m_args);
		System.setProperty("jboss.nms.service","true");//No I18N
		
		String url = null;
		String factory = "org.jnp.interfaces.NamingContextFactory"; //No I18N
		url = System.getProperty("jboss.bind.address");//No I18N

	        Hashtable ht = new Hashtable(2);
	        ht.put(Context.INITIAL_CONTEXT_FACTORY, factory);
	        ht.put(Context.PROVIDER_URL, url);

	        Context ctx = new InitialContext(ht);
	        NameLookup lookup = new NameLookupImpl();
	        ctx.bind(m_name, lookup);  // binds Web NMS Factory .!

	    //to start fe after binding WebNmsFactory     
	    StartNmsJdbc start = new StartNmsJdbc(args);    
		System.out.println(" [JBoss-WebNMS] : WebNMSService started successfully from jboss!!" );//No I18N
	}
	catch(Exception exe)
	{
		System.out.println("Exception occured in startService Method of the WebNMSService.java");//No I18N
		exe.printStackTrace();
	}
    }

    /**
     * Stops the Web NMS BE Server.
     *
     */
    public void stopService()
    {
        try{
            ShutDownAPIImpl.getInstance().shutDownNMSServer(false); // Not to do System.exit in case of JBoss
	    System.clearProperty("jboss.nms.service");//No I18N
        }
        catch(Exception e) {
		System.err.println("Exception occured while shutting down the BE Server from jboss");//No I18N
		e.printStackTrace();
	}
    }

    /**
     * Forms the key=pair string separated by comma (,) into 
     * array of String.
     *
     * @param arg a <code>String</code> String to be converted to String array.
     * @return a <code>String[]</code> formed from the passed string.
     */
    private String[] formArray(String arg)
    {
        String[] retArr = null;
        if(arg == null)
        {
            retArr = new String[0];
            return retArr;
        }
        int i = 0;
        StringTokenizer tok = new StringTokenizer(arg, ",");//No I18N
        int count = tok.countTokens();
        retArr = new String[count * 2];
        while(tok.hasMoreTokens())
        {
            String token = tok.nextToken();
            StringTokenizer intok = new StringTokenizer(token, "=");//No I18N
            retArr[i] = intok.nextToken();
            retArr[i+1] = intok.nextToken();
            i += 2;
        }
        System.out.println(" [JBoss-WebNMS] : formArray() : " +Arrays.asList(retArr));//No I18N
        return retArr;
    }

}
